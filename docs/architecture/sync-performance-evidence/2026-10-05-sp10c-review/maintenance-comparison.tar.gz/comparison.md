# Paired synchronization comparison

Bounded published-history reclamation prevents late capture backpressure without changing durability

Trial medians and ranges; failed trials have no complete latency. Individual pairs and all metrics are in comparison.json.

| CPUs | Offered rows/s | Predecessor complete / fresh | Candidate complete / fresh | Predecessor p95 median (ms) | Candidate p95 median (ms) |
| --- | --- | --- | --- | --- | --- |
| 8 | 1250 | 3/3 · 3/3 | 3/3 · 3/3 | 3047.280 | 3031.675 |
| 16 | 1250 | 3/3 · 3/3 | 3/3 · 3/3 | 3050.471 | 3035.568 |
