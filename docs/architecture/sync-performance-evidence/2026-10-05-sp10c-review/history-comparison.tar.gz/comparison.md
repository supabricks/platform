# Paired synchronization comparison

Bounded private execution history removes the admission cliff without a short-workload performance regression

Trial medians and ranges; failed trials have no complete latency. Individual pairs and all metrics are in comparison.json.

| CPUs | Offered rows/s | Predecessor complete / fresh | Candidate complete / fresh | Predecessor p95 median (ms) | Candidate p95 median (ms) |
| --- | --- | --- | --- | --- | --- |
| 8 | 1250 | 3/3 · 3/3 | 3/3 · 3/3 | 3031.971 | 3033.731 |
| 16 | 1250 | 3/3 · 3/3 | 3/3 · 3/3 | 3045.795 | 3037.253 |
