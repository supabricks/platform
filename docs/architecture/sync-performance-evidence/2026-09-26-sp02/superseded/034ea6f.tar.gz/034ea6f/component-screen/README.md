# SP02 component screen

33 randomized 10-second trials, three repetitions of each configuration; all passed independent stopped-file checks and none overlapped observed external builds. `screen.json` retains the seed, source hashes, quiet receipts and attempt outcomes. `selection-declaration.json` preceded examination of the screen; `selection-result.json` applies its thresholds.

The frozen runtime source is `be9094ccb67cadf885f00349e6c882a99b1dd970`; the later probe-only revision in the selection result leaves those capture modules unchanged. Native sync counters use the byte-identical SP01 `profile_io.so`. Each trial uses a new on-disk SQLite spool with FULL durability and DELETE journaling, periodic publication-authorized pruning, and optional bounded readers. `single=true` disables grouping in the candidate implementation; it is an ablation, not the fresh SP01 predecessor used by the full-stack matrix.

The two synthetic row events per transaction preserve complete transaction boundaries. Component rates exclude PostgreSQL, protocol decoding, Delta and publication. Sync totals include pruning. The reader-disabled control has the same independent final payload, checksum, chain and prefix-count validation; it does not measure full-stack observer overhead. Process-level durability tests do not establish power-loss guarantees.

Private logs and scratch files are excluded. Host observations use fixed process names and counters, without command lines.
