# Superseded SP02 candidate 034ea6f

The first candidate passed 33 component trials and 12 low-load profiler-control trials. Its first overload pair then exposed a deadline race in the accumulator (#104), masked by a status-file observer race (#105). The two trial reports retain their original classifications: predecessor drain timeout; candidate measurement error. The retained capture record identifies the underlying candidate runtime failure. Neither is replaced with a passing result or complete latency.

`incomplete-comparison/superseded.json` identifies the stopped controller and original/exported checksums. Its original manifest still says running_trial because the controller stopped on the error; no process remains active. Both fixtures completed cleanup with zero leaked or remaining descendants. No private logs, source payloads or scratch databases are included.

The new candidate receives fresh component screening, controls and the full 12-pair comparison. These earlier attempts remain separate and do not count toward acceptance.
